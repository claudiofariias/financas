from flask import Blueprint, render_template, request, redirect
from app.models import Saldo
from app.services import calcular_projecao

bp = Blueprint("main", __name__)


# 🔹 DASHBOARD
@bp.route("/")
def index():
    saldo = Saldo()

    if saldo.data.get("salario", 0) == 0:
        return redirect("/setup")

    projecao = calcular_projecao(saldo.data)

    return render_template("index.html", saldo=saldo.data, projecao=projecao)


# 🔹 SETUP INICIAL
@bp.route("/setup", methods=["GET", "POST"])
def setup():
    saldo = Saldo()

    if request.method == "POST":
        valor = float(request.form["valor"])
        salario = float(request.form["salario"])

        saldo.definir_saldo_inicial(valor)
        saldo.definir_salario(salario)

        return redirect("/")

    return render_template("setup.html")


# 🔹 RECEBER SALÁRIO
@bp.route("/salario", methods=["GET", "POST"])
def salario():
    saldo = Saldo()

    if request.method == "POST":
        mes = int(request.form["mes"])
        ano = int(request.form["ano"])

        saldo.receber_salario(mes, ano)

        return redirect("/")

    return render_template("salario.html")


# 🔹 RECEITA
@bp.route("/receita", methods=["GET", "POST"])
def receita():
    saldo = Saldo()

    if request.method == "POST":
        valor = float(request.form["valor"])
        saldo.adicionar_receita(valor)

        return redirect("/")

    return render_template("receita.html")


# 🔹 DESPESA
@bp.route("/despesa", methods=["GET", "POST"])
def despesa():
    saldo = Saldo()

    if request.method == "POST":
        valor = float(request.form["valor"])
        saldo.adicionar_despesa(valor)

        return redirect("/")

    return render_template("despesa.html")


# 🔹 PARCELAS
@bp.route("/parcelas", methods=["GET", "POST"])
def parcelas():
    saldo = Saldo()

    if request.method == "POST":
        valor = float(request.form["valor"])
        parcelas = int(request.form["parcelas"])
        mes = int(request.form["mes"])

        saldo.adicionar_parcela(valor, parcelas, mes)

        return redirect("/")

    return render_template("parcelas.html")


# 🔹 LISTA DE PARCELAS
@bp.route("/parcelas/lista")
def lista_parcelas():
    saldo = Saldo()
    return render_template("lista_parcelas.html", parcelas=saldo.data.get("parcelas", []))


# 🔹 RESET
@bp.route("/reset")
def reset():
    saldo = Saldo()
    saldo.limpar()
    return redirect("/")