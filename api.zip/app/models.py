from datetime import date
from app.database import saldo_collection

class Saldo:
    def __init__(self):
        self.data = saldo_collection.find_one() or {
            "valor": 0,
            "salario": 0,
            "parcelas": [],
            "despesas": [],
            "receitas": [],
            "salarios_recebidos": []
        }

    def salvar(self):
        saldo_collection.update_one({}, {"$set": self.data}, upsert=True)

    def adicionar_parcela(self, valor, parcelas, mes_inicio):
        hoje = date.today()
        valor_parcela = valor / parcelas

        for i in range(parcelas):
            mes = (mes_inicio + i - 1) % 12 + 1
            ano = hoje.year + ((mes_inicio + i - 1) // 12)

            self.data["parcelas"].append({
                "valor": valor_parcela,
                "mes": mes,
                "ano": ano
            })

        self.salvar()

        hoje = date.today()
        valor_parcela = valor / parcelas

        for i in range(parcelas):
            mes = (mes_inicio + i - 1) % 12 + 1
            ano = hoje.year + ((mes_inicio + i - 1) // 12)

            if ano == hoje.year and mes == hoje.month:
                self.data["valor"] -= valor_parcela
            else:
                self.data["parcelas"].append({
                    "valor": valor_parcela,
                    "mes": mes,
                    "ano": ano
                })
        self.salvar()
    
    def definir_saldo_inicial(self, valor):
        self.data["valor"] = valor
        self.salvar()

    def definir_salario(self, valor):
        self.data["salario"] = valor
        self.salvar()

    def adicionar_despesa(self, valor, descricao=""):
        self.data["valor"] -= valor
        self.data["despesas"].append({
            "valor": valor,
            "descricao": descricao
        })
        self.salvar()

    def adicionar_receita(self, valor, descricao=""):
        self.data["valor"] += valor
        self.data["receitas"].append({
            "valor": valor,
            "descricao": descricao
        })
        self.salvar()

    def receber_salario(self, mes, ano):
        self.data["valor"] += self.data["salario"]

        self.data["salarios_recebidos"].append({
            "mes": mes,
            "ano": ano
        })

        self.salvar()

    def limpar(self):
        saldo_collection.delete_many({})