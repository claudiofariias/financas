from datetime import date
from enum import Enum

class Mes(Enum):
    JANEIRO = 1
    FEVEREIRO = 2
    MARCO = 3
    ABRIL = 4
    MAIO = 5
    JUNHO = 6
    JULHO = 7
    AGOSTO = 8
    SETEMBRO = 9
    OUTUBRO = 10
    NOVEMBRO = 11
    DEZEMBRO = 12


class Saldo:
    def __init__(self, valor_inicial=0):
        self.valor = valor_inicial
        self.parcelas_futuras = []

    def adicionar_despesa(self, valor):
        self.valor -= valor

    def adicionar_receita(self, valor):
        self.valor += valor

    def adicionar_parcela(self, valor, parcelas, mes_inicio):
        hoje = date.today()
        valor_parcela = valor / parcelas

        # aceita Enum ou int
        if isinstance(mes_inicio, Mes):
            mes_inicio = mes_inicio.value

        for i in range(parcelas):
            mes_num = (mes_inicio + i - 1) % 12 + 1
            ano = hoje.year + ((mes_inicio + i - 1) // 12)

            mes_enum = Mes(mes_num)

            if ano == hoje.year and mes_num == hoje.month:
                self.valor -= valor_parcela
            else:
                self.parcelas_futuras.append({
                    "valor": valor_parcela,
                    "mes": mes_enum,
                    "ano": ano
                })

    def processar_mes(self, mes, ano):
        if isinstance(mes, Mes):
            mes = mes.value

        novas = []
        for p in self.parcelas_futuras:
            if p["mes"].value == mes and p["ano"] == ano:
                self.valor -= p["valor"]
            else:
                novas.append(p)

        self.parcelas_futuras = novas

    def listar_parcelas(self):
        for p in self.parcelas_futuras:
            print(f'{p["mes"].name}/{p["ano"]} - R$ {p["valor"]:.2f}')


def calcular_projecao(saldo_data, meses=12):
    from datetime import date

    hoje = date.today()
    saldo_atual = saldo_data.get("valor", 0)
    salario = saldo_data.get("salario", 0)

    projecao = []

    for i in range(meses):
        mes = (hoje.month + i - 1) % 12 + 1
        ano = hoje.year + ((hoje.month + i - 1) // 12)

        if any(s["mes"] == mes and s["ano"] == ano for s in saldo_data.get("salarios_recebidos", [])):
            saldo_atual += salario

        for p in saldo_data.get("parcelas", []):
            if p["mes"] == mes and p["ano"] == ano:
                saldo_atual -= p["valor"]

        projecao.append({
            "mes": mes,
            "ano": ano,
            "saldo": round(saldo_atual, 2)
        })

    return projecao